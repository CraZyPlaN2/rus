<?php

/**
 * Regular URL scheme for pun_tags.
 *
 * @copyright Copyright (C) 2008 PunBB
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package pun_tags
 */

$pun_tags_url = array(
	'Section pun_tags'		=>	'admin/extensions.php?section=manage_tags',
	'Section tags'			=>	'admin/extensions.php?section=manage_tags&tags=1',
);
?>