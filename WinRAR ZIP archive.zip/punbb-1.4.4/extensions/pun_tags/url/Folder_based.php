<?php
/**
 * Folder based SEF URL scheme.
 *
 * @copyright Copyright (C) 2008 PunBB
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package pun_tags
 */

$forum_url['search_tag'] = 'tag/$1/';

?>
