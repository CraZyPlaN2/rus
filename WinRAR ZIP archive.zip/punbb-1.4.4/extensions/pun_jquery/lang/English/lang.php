<?php

if (!defined('FORUM'))
	die();

$lang_pun_jquery = array(
	'Setup jquery'						=> 'jQuery (version %s)',
	'Setup jquery legend'				=> 'jQuery (version %s)',

	'Include method'					=> 'Include method',

	'Include method local label'		=> 'Local',
	'Include method google label'		=> 'Google Ajax API CDN ',
	'Include method microsoft label'	=> 'Microsoft CDN',
	'Include method jquery label'		=> 'jQuery CDN',
);

?>
