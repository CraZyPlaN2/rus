<?php

if (!defined('FORUM')) die();

$lang_pun_bbcode = array(
	'Pun BBCode Bar'				=> 'Use BBCode Bar',
	'Notice BBCode Bar'				=> 'Enable BBCode Bar when writing posts',
	'BBCode Graphical'				=> 'Use graphical buttons',
	'BBCode Graphical buttons'		=> 'Use graphical buttons in BBcode Bar'
)

?>
