<?php

if (!defined('FORUM')) die();

$lang_pun_admin_clear_cache = array(
	'Clear cache'	=> 'Clear&nbsp;cache',
	'Cleard'		=> 'All the /cache/cache_*.php files has been successfully removed.'
);