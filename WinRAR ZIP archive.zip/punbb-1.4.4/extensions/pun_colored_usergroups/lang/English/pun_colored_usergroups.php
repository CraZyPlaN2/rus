<?php

/**
 * pun_colored_usergroups functions file
 *
 * @copyright (C) 2008-2012 PunBB
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package pun_colored_usergroups
 */

if (!defined('FORUM')) die();

$lang_pun_colored_usergroups = array(
	'link'		=>	'Link colour',
	'hover'		=>	'Hover colour',
);

?>
